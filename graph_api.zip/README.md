# Instantly Campaign API Analytics

This codebase provides Python modules and scripts to interact with the Instantly API for campaign management and analytics.

## Features
- Fetch all campaign IDs from your Instantly workspace
- Retrieve daily analytics for campaigns (emails sent, opened, replies, clicks, etc.)
- Save analytics results as JSON for further analysis
- Example test scripts for batch analytics over multiple days

## Modules
- `instantly_campaign_api.py`: Get campaign IDs
- `instantly_campaign_analytics_api.py`: Get daily analytics for campaigns
- `test_instantly_campaign_api.py`: Test fetching campaign IDs and analytics
- `test_campaign_id_and_analytics.py`: Fetch analytics for the first 10 campaigns for the last 7 days and save as JSON

## Usage
1. Install dependencies:
   ```bash
   pip install requests
   ```
2. Set your Instantly API key in the test scripts (`API_KEY` variable).
3. Run the test scripts:
   ```bash
   python test_instantly_campaign_api.py
   python test_campaign_id_and_analytics.py
   ```
4. Check the generated JSON files for analytics results.

## API Reference
- [Instantly API Documentation](https://api.instantly.ai/docs)

## Notes
- Ensure your API key has the required scopes: `campaigns:read`, `campaigns:all`, etc.
- The analytics API returns data only for valid, active campaigns and dates with activity.
- For debugging, add logging or print statements as needed.

## License
MIT
