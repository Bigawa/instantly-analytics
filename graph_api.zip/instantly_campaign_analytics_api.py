import requests
from typing import Optional, Dict, Any

class InstantlyCampaignAnalyticsAPI:
    BASE_URL = "https://api.instantly.ai/api/v2/campaigns/analytics/daily"

    def __init__(self, api_key: str):
        self.api_key = api_key
        self.headers = {
            "Authorization": f"Bearer {self.api_key}"
        }

    def get_daily_campaign_analytics(self, campaign_id: str, date: str, campaign_status: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """
        Fetch daily analytics for a given campaign and date.
        Args:
            campaign_id: Campaign UUID.
            date: Date in YYYY-MM-DD format.
            campaign_status: Optional campaign status filter.
        Returns:
            Dictionary with analytics for the given day, or None if not found.
        """
        params = {
            "campaign_id": campaign_id,
            "start_date": date,
            "end_date": date
        }
        if campaign_status is not None:
            params["campaign_status"] = campaign_status
        response = requests.get(self.BASE_URL, headers=self.headers, params=params)
        response.raise_for_status()
        data = response.json()
        # Find analytics for the given date
        for entry in data:
            if entry.get("date") == date:
                return entry
        return None
